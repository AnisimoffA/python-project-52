# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['labels',
 'labels.migrations',
 'statuses',
 'statuses.migrations',
 'task_manager',
 'task_manager.migrations',
 'tasks',
 'tasks.migrations',
 'users',
 'users.migrations']

package_data = \
{'': ['*'],
 'task_manager': ['templates/*',
                  'templates/labels/*',
                  'templates/statuses/*',
                  'templates/tasks/*',
                  'templates/users/*']}

install_requires = \
['django-bootstrap4>=23.2,<24.0',
 'django-extensions>=3.2.3,<4.0.0',
 'django>=4.2.4,<5.0.0',
 'flake8>=4.0.1,<5.0.0',
 'gunicorn>=21.2.0,<22.0.0',
 'psycopg2-binary>=2.9.7,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'whitenoise>=6.5.0,<7.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.0.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AnisimoffA/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/AnisimoffA/python-project-52/actions)\n\n',
    'author': 'Anisimoff',
    'author_email': 'happyprooo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

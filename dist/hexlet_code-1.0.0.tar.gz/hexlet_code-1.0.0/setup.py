# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['labels',
 'labels.migrations',
 'statuses',
 'statuses.migrations',
 'task_manager',
 'task_manager.migrations',
 'tasks',
 'tasks.migrations',
 'users',
 'users.migrations']

package_data = \
{'': ['*'],
 'task_manager': ['templates/*',
                  'templates/labels/*',
                  'templates/statuses/*',
                  'templates/tasks/*',
                  'templates/users/*']}

install_requires = \
['django-bootstrap4>=23.2,<24.0',
 'django-extensions>=3.2.3,<4.0.0',
 'django>=4.2.4,<5.0.0',
 'flake8>=4.0.1,<5.0.0',
 'gunicorn>=21.2.0,<22.0.0',
 'psycopg2-binary>=2.9.7,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'rollbar>=0.16.3,<0.17.0',
 'whitenoise>=6.5.0,<7.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.0.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AnisimoffA/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/AnisimoffA/python-project-52/actions)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/9388f6ca6f9296e88a1d/test_coverage)](https://codeclimate.com/github/AnisimoffA/python-project-52/test_coverage)\n\nTask Manager link: [Here](python-project-52-production-312b.up.railway.app)\n\n### Description\n\nThis framework is a convenient task manager built on python 3.8 and django 4.2. To use the system, you must be registered.\n\n![img.png](images/img.png)\n![img_1.png](images/img_1.png)\n___\nHere You can create a task list\n\n![img.png](images/img3.png)\n\nand also You can also view all the tasks, change their status and add the necessary labels.\n\n![img.png](images/img4.png)\n\n___\n### How to use it?\n\nFirstly, clone the repo:\n```python\ngit clone https://github.com/AnisimoffA/python-project-52\n```\n\nSecondary, generate an .env file located in the project\'s primary directory. You will be required to define specific variables within it:\n```python\nDATABASE_URL={provider}://{user}:{password}@{host}:{port}/{db}\nSECRET_KEY={your secret key}\nLANGUAGE=en-us # Or "ru" if you want\n```\n\nThirdly, run the server:\n```python\npython3 manage.py runserver\n```\n___\n### Requirements\n\n- Python ^3.2\n- Django ^4.2\n- Flake8 ^4.0.1\n- Bootstrap 4\n- Gunicorn ^21.0.0',
    'author': 'Anisimoff',
    'author_email': 'happyprooo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

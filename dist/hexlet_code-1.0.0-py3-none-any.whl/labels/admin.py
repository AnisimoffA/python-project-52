from django.contrib import admin # NOQA F401

# Register your models here.

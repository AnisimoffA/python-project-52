from django.apps import AppConfig


class LabelsConfig(AppConfig):
    name = 'labels'
    verbose_name = 'Метки'

from django.apps import AppConfig


class StatusesConfig(AppConfig):
    name = 'statuses'
    verbose_name = 'Пользователи'
